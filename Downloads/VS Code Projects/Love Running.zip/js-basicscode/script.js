  // This is a simple JavaScript code that logs "Hello, World!" to the console
        console.log("Hello, World!");

        let name = "Tendayi";
        name = "Tendayi";
        console.log(name);
        
        // cannot be a reserved keyword 
        // should be meaningful
        // cannot start with a number
        // cannot contain a space or hyphen (-)
        // are case-sensitive

    if (false) {
    console.log('The code in this block will not run.');
} else {
  console.log('But the code in this block will!');
}

// Prints: But the code in this block will!

